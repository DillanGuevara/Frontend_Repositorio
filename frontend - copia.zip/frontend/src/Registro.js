import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import logo from './logo.svg';

function Registro() {
  return (
    <div className="Registro">

      <nav className="nav-container">  
        <img src={logo} alt="assets/img/logo.svg" className="logo" />
        <span className="company-name">SanBra Seguridad y Seguros</span>
      </nav>

      <header>
        <div>
          <h1>Registrarse</h1>
              <form>
                  <label for="name">Nombre:</label>
                  <input type="text" id="name" />
                  <label for="email">Correo electrónico:</label>
                  <input type="email" id="email" />
                  <label for="password">Contraseña:</label>
                  <input type="password" id="password" />
                  <button type="submit">Registrarse</button>
              </form>
        </div>
      </header>

        <footer>
            <p>SanBra Seguridad y Seguros<br></br>
            versión 1.0<br></br>
            2024</p>
        </footer>

    </div>
    
  );
}

export default Registro;
