import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import logo from './logo.svg';
import './App.css';
import InicioSesion from './InicioSesion';
import Registro from './Registro';
import alcoholImage from './img/alcohol.png';
import botiquinImage from './img/botiquin.jpg';
import cascoImage from './img/casco.jpg';
import gafasImage from './img/gafas.png';
import guantesImage from './img/guantes.jpg';
import mascaraImage from './img/mascara.png';

function App() {

  return (

  <Router>

    <div className="App">

      <nav className="nav-container">  
        <img src={logo} alt="assets/img/logo.svg" className="logo" />
        <span className="company-name">SanBra Seguridad y Seguros</span>
      </nav>

    <header>
      <center>
        <h1>Productos de seguridad industrial en los que puedes confiar.</h1>
        <div className="App">
            <Routes>
                <Route path="/InicioSesion" element={<InicioSesion />} />
                <Route path="/Registro" element={<Registro />} />
            </Routes>

            <Link to="/InicioSesion">
                <button>Iniciar sesión</button>
            </Link>
            <Link to="/Registro">
                <button>Registrarse</button>
            </Link>

        </div>

          <img src={alcoholImage} alt="Alcohol Safety Product" className="header-image" /><br></br>
          <img src={botiquinImage} alt="Botiquin Safety Product" className="header-image" /><br></br>
          <img src={cascoImage} alt="Casco Safety Product" className="header-image" /><br></br>
          <img src={gafasImage} alt="Gafas Safety Product" className="header-image" /><br></br>
          <img src={guantesImage} alt="Guantes Safety Product" className="header-image" /><br></br>
          <img src={mascaraImage} alt="Mascara Safety Product" className="header-image" /><br></br>
        </center>

    </header>
        
        <footer>
            <p>SanBra Seguridad y Seguros<br></br>
            versión 1.0<br></br>
            2024</p>
        </footer>

    </div>

  </Router>
    
  );
}

export default App;
