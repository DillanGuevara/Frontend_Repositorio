import React from "react";
import { Link } from "react-router-dom"; 
const links = [
    {
        name: "Home",
        href: "Home",
    }
];

const NavBar = () => {
    return <div>
    {links.map((x) => (
        <Link to ={(x.home)}</Link>
    ))} 
    </div>
    );
};

export default NavBar;