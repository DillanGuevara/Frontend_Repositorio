import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer-container">
      <div className="footer-content">
        <div className="footer-left">
          <p>SanBra Seguridad y Seguros</p>
          <p>versión 1.0</p>
          <p>2024</p>
        </div>
        <div className="footer-right">
            
        </div>
      </div>
    </footer>
  );
};

export default Footer;
