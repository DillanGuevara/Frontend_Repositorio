import logo from './logo.svg';
import './App.css';

function Home() {
    return (
        <div className="App">
            <h1>Hola Mundo</h1>
        </div>
    )
}

export default Home;