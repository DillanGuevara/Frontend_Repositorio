import logo from './logo.svg';
import './App.css';

function Header() {
    return (
        <div className="App">
            <h1>Hola Mundo</h1>
        </div>
    )
}

export default Header;