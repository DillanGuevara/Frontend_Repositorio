import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import logo from './logo.svg';

function InicioSesion() {
  return (

    <div className="InicioSesion">

      <nav className="nav-container">  
        <img src={logo} alt="assets/img/logo.svg" className="logo" />
        <span className="company-name">SanBra Seguridad y Seguros</span>
      </nav>

    <header>
      <h1>Iniciar sesión</h1>
      <form>
        <label for="username">Nombre de usuario:</label>
        <input type="text" id="username" />
        <label for="password">Contraseña:</label>
        <input type="password" id="password" />
        <button type="submit">Iniciar sesión</button>
      </form>
    </header>

    <footer>
        <p>SanBra Seguridad y Seguros<br></br>
        versión 1.0<br></br>
        2024</p>
    </footer>

    </div>
  );
}

export default InicioSesion;
